package bookstore;

public enum Param {
    VISITORS, CASHIERS, ITEMS, MAXITEMS, SHOPPING, CHECKOUT, TIME, QUEUEBOUND, DISPLAY;
}
